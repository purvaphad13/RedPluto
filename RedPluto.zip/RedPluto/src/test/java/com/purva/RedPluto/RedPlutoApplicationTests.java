package com.purva.RedPluto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedPlutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
