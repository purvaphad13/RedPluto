package com.purva.RedPluto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedPlutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedPlutoApplication.class, args);
	}

}
